﻿Build Date : 2026-06-18 15:53:01

Stock No   : 92740654

Core Ver   : 02

Param Ver  : 00

Version    : RF_92740654-V02_V00

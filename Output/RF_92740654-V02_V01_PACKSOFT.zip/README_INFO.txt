﻿Build Date : 2026-06-18 16:21:04

Stock No   : 92740654

Core Ver   : 02

Param Ver  : 01

Version    : RF_92740654-V02_V01

﻿Build Date : 2026-11-12 11:07:40

Stock No   : 92740654

Core Ver   : 03

Param Ver  : 02

Version    : RF_92740654-V03_V02
